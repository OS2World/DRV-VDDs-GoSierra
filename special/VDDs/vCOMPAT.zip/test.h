extern char     MagicData_TurboPascalCRT;

extern void MagicVMP_ProcessArea      (char *MagicDataPtr, char *AreaPtr, ulong AreaLength);
