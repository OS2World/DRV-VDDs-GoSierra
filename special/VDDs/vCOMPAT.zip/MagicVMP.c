
/* vCOMPAT is for OS/2 only */
/*  You may not reuse this source or parts of this source in any way and/or */
/*  (re)compile it for a different platform without the allowance of        */
/*  kiewitz@netlabs.org. It's (c) Copyright by Martin Kiewitz.              */

#include <mvdmndoc.h>
#define INCL_VDH
#define INCL_VDHVDMA
#define INCL_SSTODS
#include <mvdm.h>                       /* VDH services, etc.        */

#include <globaldefs.h>
#include <vcompat.h>
#include <asm\main.h>

VOID VCOMPAT_PatchDeviceDriverHeaders (void) {
   PVOID  DeviceDriverPtr = (PVOID)((ULONG)PTR_ListOfLists+0x22);
   ULONG  NxtDeviceDrvPtr;
   ULONG  CharDevName1, CharDevName2;
   UCHAR  TempVal;
   USHORT DeviceDriverCounter = 0;

   while (1) {
      CharDevName1 = *(PULONG)((ULONG)DeviceDriverPtr+10);
      CharDevName2 = *(PULONG)((ULONG)DeviceDriverPtr+14);

      if ((CharDevName1=='DCSM') & (CharDevName2==' 100')) { // MSCD001_
         // VCDROM Device-Header
         TempVal = *(PUCHAR)((ULONG)DeviceDriverPtr+20); // Drive-Letter Byte
         // Only patch, when current Drive-Letter==0 and CDROM-Patch injected
         //  We won't patch our VCDROM replacement device header, because that
         //  one already has the correct Drive-Letter byte set.
         if ((TempVal==0) & (PATCH_CDROMinDOSptr!=0)) {
            // +24 -> hard-coded, points to 1st CD-ROM drive letter
            TempVal = *(PUCHAR)((ULONG)PATCH_CDROMinDOSptr+24);
            // we need base 1, but we got base 0 in table, that's why +1
            *(PUCHAR)((ULONG)DeviceDriverPtr+20) = TempVal+1;
          }
       }

      NxtDeviceDrvPtr = *(PULONG)DeviceDriverPtr;
      if (WORDOF(NxtDeviceDrvPtr,0)==0xFFFF) break;

      DeviceDriverPtr = PFROMVP(NxtDeviceDrvPtr);

      // If we dont find End-Of-Device-Driver-Chain after 50 headers, we assume
      //  that something went wrong...
      DeviceDriverCounter++;
      if (DeviceDriverCounter>50) break;
    }
   return;
 }

BOOL VCOMPAT_MagicVMpopup (uchar *TextMessagePtr) {
   ULONG  popupresult = 0;
   if (PROPERTY_VMPatcherAUTO) return TRUE;
   VDHPopup (TextMessagePtr, 1, MSG_DIRECTSTRING, SSToDS(&popupresult), VDHP_IGNORE, NULL);
   return (popupresult==VDHP_TERMINATE_SESSION);
 }

PUCHAR VCOMPAT_SearchSignatureInMCB (uchar *MagicDataPtr, uchar *OpCodePtr, long AdjustOffset, ulong MaxLength) {
   PUCHAR CurMCBpointer = PTR_FirstMCB;
   PUCHAR NextMCBpointer;
   ULONG  TotalLength;

   while ((*CurMCBpointer==0x4D) || (*CurMCBpointer==0x5A)) {
      // Get pointer to next MCB...
      NextMCBpointer = CurMCBpointer+(((ulong)(*(PUSHORT)(CurMCBpointer+3))+1)<<4);
      if (NextMCBpointer>OpCodePtr) {
         // Okay, we found the correct MCB...
         OpCodePtr += AdjustOffset;      // OpCodePtr is now SearchStartPtr
         if (OpCodePtr<=CurMCBpointer)   // if not within MCB -> Adjust
            OpCodePtr = (PUCHAR)((ulong)CurMCBpointer+16);

         // Calculate Total-Length from SearchStart to End-Of-MCB
         TotalLength = NextMCBpointer-OpCodePtr;
         if (MaxLength>TotalLength)
            MaxLength = TotalLength;     // And adjust accordingly...
         // Now finally search for the signature...
         return MagicVMP_SearchSignature (MagicDataPtr, OpCodePtr, MaxLength);
       }
      CurMCBpointer = NextMCBpointer;
    }
   return 0; // Corresponding MCB not found... (should never be the case)
 }

// Searches for Turbo Pascal CRT Unit V86 bug...
VOID VCOMPAT_MagicVMPatcherInRM_TurboPascalCRT (PCRF pcrf) {
   PUCHAR  OpCodePointer;
   PUCHAR  SignaturePtr = 0;

   // If VDM running in Protected Mode -> Dont try VM-Patching!
   if (flVdmStatus & VDM_STATUS_VPM_APP) return;
   if (!PROPERTY_VMPatcherON) return;

   // Try to find Turbo Pascal CRT-Unit bugger...
   OpCodePointer = PFROMVADDR(CS(pcrf),IP(pcrf));
   SignaturePtr = VCOMPAT_SearchSignatureInMCB (&MagicData_TurboPascalCRT, OpCodePointer, -8000, 8000);
   if ((SignaturePtr!=0) && (VCOMPAT_MagicVMpopup(&MagicData_TurboPascalCRTtext)))
      MagicVMP_ApplyPatch (&MagicData_TurboPascalCRTpatch, SignaturePtr);
 }

// Searches for Micro$loft buggy C unit code
//  found in Monkey Island 1, Indiana Jones and many more
VOID VCOMPAT_MagicVMPatcherInRM_MS_C_TimerInitBug (PCRF pcrf) {
   PUCHAR  OpCodePointer;
   PUCHAR  SignaturePtr = 0;

   // If VDM running in Protected Mode -> Dont try VM-Patching!
   if (flVdmStatus & VDM_STATUS_VPM_APP) return;
   if (!PROPERTY_VMPatcherON) return;

   // Try to find M$ C Timer Init bugger...
   OpCodePointer = PFROMVADDR(CS(pcrf),IP(pcrf));
   SignaturePtr = VCOMPAT_SearchSignatureInMCB (&MagicData_MicrosuckC, OpCodePointer, -12000, 12000);
   if ((SignaturePtr!=0) && (VCOMPAT_MagicVMpopup(&MagicData_MicrosuckCtext)))
      MagicVMP_ApplyPatch (&MagicData_MicrosuckCpatch, SignaturePtr);
 }

// Searches for Clipper unit code
VOID VCOMPAT_MagicVMPatcherInRM_Clipper_TimerBug (PCRF pcrf) {
   PUCHAR  OpCodePointer;
   PUCHAR  SignaturePtr = 0;

   // If VDM running in Protected Mode -> Dont try VM-Patching!
   if (flVdmStatus & VDM_STATUS_VPM_APP) return;
   if (!PROPERTY_VMPatcherON) return;

   // Try to find Clipper Timer Init bugger...
   OpCodePointer = PFROMVADDR(CS(pcrf),IP(pcrf));
   SignaturePtr = VCOMPAT_SearchSignatureInMCB (&MagicData_Clipper, OpCodePointer, 0, 128000);
   if ((SignaturePtr!=0) && (VCOMPAT_MagicVMpopup(&MagicData_ClipperText)))
      MagicVMP_ApplyPatch (&MagicData_ClipperPatch, SignaturePtr);
 }

// This is bad boy code, because we search through all code selectors that are
//  open till that time which means we waste much time, but it's working and
//  the TurboPascalDPMI-Trigger is somewhat safe, so time won't be wasted on
//  normal applications.
VOID VCOMPAT_MagicVMPatcherInPM_TurboPascalCRT () {
   PUCHAR  SignaturePtr = 0;

   // Try to find Turbo Pascal DPMI CRT-Unit bugger...
   SignaturePtr = MagicVMP_SearchSignatureInSel (&MagicData_TurboPascalCRT, 20000);
   if ((SignaturePtr!=0) && (VCOMPAT_MagicVMpopup(&MagicData_TurboPascalCRTDPMItext))) {
      MagicVMP_ApplyPatch (&MagicData_TurboPascalCRTpatch, SignaturePtr);
      TRIGGER_TurboPascalDPMI = 0;
    }
 }

// This trigger is executed as soon as possible after program execution.
// It's meant for e.g. games that switch to another videomode and/or do output
//  via INT10h. We assume that an encoded program is fully decoded till INT10h.
VOID VCOMPAT_MagicVMPatcherInPM_INT10 (PCRF pcrf) {
   // If VDM is NOT running a Protected Mode application -> Exit!
   if (!(flVdmStatus & VDM_STATUS_VPM_APP)) return;

   // User allowed us to patch?
   if (!PROPERTY_VMPatcherON) return;

   if (flVdmStatus & VDM_STATUS_VPM_32) {
      // 32-bit applications - we do Anti-CLI Patching
      MagicVMP_DoAntiCLI();                 // Processes Anti-CLI
    } else {
      // 16-bit applications - we check if Turbo Pascal Trigger is active
      if (TRIGGER_TurboPascalDPMI) {
         VCOMPAT_MagicVMPatcherInPM_TurboPascalCRT();
       }
    }
   VDD_ResetMemSelTable();
 }

VOID HOOKENTRY VCOMPAT_AutoVPMSti (PVOID p, PCRF pcrf) {
   // Enable Interrupts...
   if (flVdmStatus & VDM_STATUS_VPM_APP) {
      VDHChangeVPMIF (1);
    }
   VDHArmTimerHook (AutoVPMStiTimerHandle, 50, CurVDMHandle);
 }

