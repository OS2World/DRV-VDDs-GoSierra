// Automatically generated file - do not modify

extern ushort PATCH_2GBLIMITlength;
extern char   PATCH_2GBLIMIT;
extern ushort PATCH_CDROMlength;
extern char   PATCH_CDROM;
extern ushort PATCH_CDROMREPlength;
extern char   PATCH_CDROMREP;
extern ushort PATCH_COMPATDDlength;
extern char   PATCH_COMPATDD;
extern ushort PATCH_DPMITRIGlength;
extern char   PATCH_DPMITRIG;
extern ushort PATCH_INT25length;
extern char   PATCH_INT25;
extern ushort PATCH_JOYSTICKlength;
extern char   PATCH_JOYSTICK;
extern ushort PATCH_MOUSENSElength;
extern char   PATCH_MOUSENSE;
