
/* vCOMPAT is for OS/2 only */
/*  You may not reuse this source or parts of this source in any way and/or */
/*  (re)compile it for a different platform without the allowance of        */
/*  kiewitz@netlabs.org. It's (c) Copyright by Martin Kiewitz.              */

#include <16bit\modules.h>

/* CONST.asm */
extern char     CONST_COMPAT_InitMessage;
extern char     CONST_COMPAT_MAIN;
extern char     CONST_COMPAT_COPYRIGHT;
extern char     CONST_COMPAT_2GBLIMIT;
extern char     CONST_COMPAT_CDROM;
extern char     CONST_COMPAT_CDROM_REPLACE;
extern char     CONST_COMPAT_DPMI;
extern char     CONST_COMPAT_DPMI_NOHOOK;
extern char     CONST_COMPAT_DPMI_ANTICLI;
extern char     CONST_COMPAT_JOYSTICKBIOS;
extern char     CONST_COMPAT_MAGICVMPATCHER;
extern char     CONST_COMPAT_MAGICVM_ENUM;
extern char     CONST_COMPAT_MAGICVM_AUTO;
extern char     CONST_COMPAT_MAGICVM_ON;
extern char     CONST_COMPAT_MAGICVM_OFF;
extern char     CONST_COMPAT_MOUSENSE;

extern char     CONST_CDROM_CHARDEV;
extern char     CONST_COMPAT_DevName;
extern char     CONST_DPMDOS;
extern char     CONST_VCDROM;

/* GlobalData.asm */
extern PUCHAR   OrgINT31RouterPtr;
extern PUCHAR   OrgINT31CreateTaskPtr;
extern PUCHAR   OrgINT31EndTaskPtr;
extern PUCHAR   OrgINT31QueryPtr;
extern BOOL     TRIGGER_VCDROMReplacement;

/* MagicVMP_data.inc */
extern uchar    MagicData_TurboPascalCRT;
extern uchar    MagicData_TurboPascalCRTtext;
extern uchar    MagicData_TurboPascalCRTpatch;
extern uchar    MagicData_TurboPascalCRTDPMItext;
extern uchar    MagicData_MicrosuckC;
extern uchar    MagicData_MicrosuckCtext;
extern uchar    MagicData_MicrosuckCpatch;
extern uchar    MagicData_Clipper;
extern uchar    MagicData_ClipperText;
extern uchar    MagicData_ClipperPatch;
extern uchar    MagicData_INT31Router;
extern uchar    MagicData_INT31CreateTask;
extern uchar    MagicData_INT31EndTask;
extern uchar    MagicData_INT31Query;

// Variables in Instance Data-Segment (for every VDM)
extern HVDM     CurVDMHandle;
extern VPVOID   VCOMPAT_APIBreakPoint;
extern PBVDM    PATCH_DeviceDriverInDOSptr;
extern PBVDM    PATCH_2GBLIMITinDOSptr;
extern PBVDM    PATCH_CDROMinDOSptr;
extern PBVDM    PATCH_DPMITRIGinDOSptr;
extern PBVDM    PATCH_INT25inDOSptr;
extern PBVDM    PATCH_JOYSTICKBIOSinDOSptr;
extern PBVDM    PATCH_MOUSENSEinDOSptr;
extern PBVDM    PATCH_FirstPatchSegPtr;
extern PBVDM    PATCH_LastPatchSegPtr;
extern BOOL     PROPERTY_DPMI;
extern BOOL     PROPERTY_DPMIAntiCLI;
extern BOOL     PROPERTY_VMPatcherON;
extern BOOL     PROPERTY_VMPatcherAUTO;
extern BOOL     TRIGGER_InINT21Execute;
extern BOOL     TRIGGER_TurboPascalDPMI;
extern BOOL     TRIGGER_CompatDDInstalled;

extern CHAR     CDROM_CHARDEV_Information;
extern USHORT   CDROM_DriveCount;
extern USHORT   CDROM_FirstDriveNo;

extern HHOOK    AutoVPMStiTimerHandle;

extern PUCHAR   PTR_FirstMCB;            // -> first MCB-Block in current VDM
extern PVOID    PTR_ListOfLists;         // -> ListOfLists (AH=52h/INT21)

/* Instance.asm */
extern VOID     VDD_INT3();
extern VOID     VDD_InitInstanceData();
extern VOID     VDD_ResetMemSelTable();
extern VOID     VCOMPAT_InitPatchModules();
extern BOOL     VCOMPAT_APIEntry(PVOID pHookData, PCRF pcrf);

/* MagicVMP.asm */
extern PUCHAR   MagicVMP_SearchSignature  (uchar *MagicDataPtr, uchar *AreaPtr, ulong AreaLength);
extern PUCHAR   MagicVMP_SearchSignatureInSel (uchar *MagicDataPtr, ulong MaxSize);

extern void     MagicVMP_ApplyPatch       (uchar *MagicPatchPtr, uchar *SignaturePtr);
extern void     MagicVMP_DoAntiCLI        ();
extern void     MagicVMP_DoRemoveTPCRTbug ();

/* DPMIrouter.asm */
extern void     DPMIRouter_InjectedCode   ();

/* V86Hooks.asm */
extern void     V86PreHook_INT21h         ();
