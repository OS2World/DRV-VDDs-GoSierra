
/* vCOMPAT is for OS/2 only */
/*  You may not reuse this source or parts of this source in any way and/or */
/*  (re)compile it for a different platform without the allowance of        */
/*  kiewitz@netlabs.org. It's (c) Copyright by Martin Kiewitz.              */

extern HVDM    MyVDMHandle;
extern HHOOK   AutoVPMStiTimerHandle;

extern BOOL    PropertyVMPatcherON;
extern BOOL    PropertyVMPatcherAUTO;

extern PUCHAR  FirstMCBpointer;
